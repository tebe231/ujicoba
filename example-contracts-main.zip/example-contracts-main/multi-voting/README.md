# Multi Voting

This is the example multi-voting contract. Its a factory contract that deploys new voting contracts that can be voted on. The contract keeps track of deployed voting contracts and their proposal
ids, such that voters can vote on them. Users can then go to the deployed contracts to submit their votes.