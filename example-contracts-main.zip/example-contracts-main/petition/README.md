# Petition

Example smart contract implementing a simple petition signing. 

How it works
* The owner of the petition deploys it with a description of what other users are signing.
* Other users can then sign the petition.
